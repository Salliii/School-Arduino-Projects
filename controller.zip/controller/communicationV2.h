/*
 * Bibliothek: 		communicationV2.h
 * Version:		    2.0
 * erstellt am:		12.02.2019
 * letzte �nderung:	12.02.2019
 * Autor:		    Busch Michael
 */

/* TR 3.5 Beschreibung:
   Serielle Schnittstelle und I2C-Bus
*/

#include "controller.h" 	//FA 205 Bibliothek

//I2C SDA und SCL Portpins festlegen

#define SDA A4
#define SCL A5


//RS232 Serielle Schittstelle
void    rs232_init(void);
uint8_t rs232_get(void);
void    rs232_put(uint8_t value);
void    rs232_print(uint8_t text[]);
void    rs232_print(String str);

//I2C-Bussystem
void    i2c_init(void);
uint8_t i2c_start_addrRW(uint8_t addresse);
void	i2c_start(void);
void    i2c_stop(void);
//uint8_t i2c_write(uint8_t value);
void 	i2c_write(uint8_t value);
uint8_t i2c_read(uint8_t ack);
void    short_delay(void);
void	takt(void);
