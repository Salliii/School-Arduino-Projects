/*
 * Datei:     lcd.cpp
 * f�r:       Arduino Uno 
 * Created:   02.04.2016
 * ge�ndert:  02.04.2016
 * Author:    Baier
 */

#include "lcd.h"	          //FA 205 Bibliothek
#include <LiquidCrystal.h>    //Arduino Bibliothek
#include <arduino.h>

/* TR 3.4: LC-Display
 * Implementierung f�r Arduino
 * Beschaltung LC-Display:
 * - LCD RS pin to digital pin 9
 * - LCD Enable pin to digital pin 8
 * - LCD D4 pin to digital pin 4
 * - LCD D5 pin to digital pin 5
 * - LCD D6 pin to digital pin 6
 * - LCD D7 pin to digital pin 7
 * - LCD R/W pin to ground
 * - LCD VSS pin to ground
 * - LCD VCC pin to 5V
 * - 10K resistor:
 * - ends to +5V and ground
 * - wiper to LCD VO pin (pin 3) 
*/ 

#define  RS_Pin    9
#define  E_Pin     8
#define  DB4_Pin   4
#define  DB5_Pin   5
#define  DB6_Pin   6
#define  DB7_Pin   7

LiquidCrystal mein_LCD(RS_Pin,E_Pin,DB4_Pin,DB5_Pin,DB6_Pin,DB7_Pin);

void lcd_init(void)
{
	mein_LCD.begin(16, 2);
}

void lcd_clear(void)
{
     mein_LCD.clear();
}

void lcd_setcursor(uint8_t zeile, uint8_t spalte)
{
    mein_LCD.setCursor(spalte, zeile);  
}

void lcd_print(uint8_t text[])
{
	String str="";
	int pos=0;
	while( text[pos]!=0 ) {
		str = str+(char)text[pos];
		pos++;
	}
	mein_LCD.print(str);
}

//�berladene Funktion f�r Zeichenkette
void lcd_print(String str)
{
	mein_LCD.print(str);
}

void lcd_char(uint8_t value)
{
	mein_LCD.print((char)value);
}

void lcd_byte(uint8_t value)
{
	mein_LCD.print((byte)value);
}

void lcd_int(uint16_t value)
{
	mein_LCD.print((unsigned int)value);
}

//*********************************
