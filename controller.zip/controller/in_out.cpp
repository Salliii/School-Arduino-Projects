/*
 * Datei:	 in_out.cpp
 * Created:  Rahm (Stand 30.09.2015)
 * �nderung: 02.04.2016
 *  Author:  Rahm, Baier
 */ 

 // TR 3.2: Bit/Byte Ein-/Ausgabe Implementierung Arduino

#include "in_out.h"   //FA 205 Bibliothek

//************************************************************
// Funktionen zur Initialisierung
void bit_init(volatile uint8_t *byte_adr, uint8_t bit_nr, uint8_t dir)
{
	uint8_t bit_config = OUT;
	
	if (dir == OUT)
	{
		if (byte_adr == _PORTD_)	_PORTD_CFG |= (0x01<<bit_nr);
		if (byte_adr == _PORTB_)	_PORTB_CFG |= (0x01<<bit_nr);
		if (byte_adr == _PORTC_)	_PORTC_CFG |= (0x01<<bit_nr);
	}
	else
	{
		if (byte_adr == _PORTD_)	_PORTD_CFG &= ~(0x01<<bit_nr);
		if (byte_adr == _PORTB_)	_PORTB_CFG &= ~(0x01<<bit_nr);
		if (byte_adr == _PORTC_)	_PORTC_CFG &= ~(0x01<<bit_nr);
	}
	#ifdef	PULLUPS
	if (dir == IN) *byte_adr |= (0x01<<bit_nr);	// internen Pullup aktivieren
	#endif
}

void byte_init(volatile uint8_t *byte_adr, uint8_t dir)
{
	uint8_t reg_config;
	
	if (dir == OUT)
	{
		reg_config = 0xff;
	}
	else
	{
		reg_config = 0x00;
	}
	
	if		(byte_adr == _PORTD_)	_PORTD_CFG = reg_config;
	else if (byte_adr == _PORTB_)	_PORTB_CFG = reg_config;
	else if (byte_adr == _PORTC_)	_PORTC_CFG = reg_config;
	#ifdef PULLUPS
	if (dir == IN) *byte_adr = 0xff;	// interne Pullups aktivieren
	#endif
}


//--------FUNKTION for loop--------:
//bit_read(_reg_, bit)	(((_reg_)>>(bit)) & 0x01)
uint8_t bit_read(volatile uint8_t *byte_adr, uint8_t bit_nr)
{
	if		(byte_adr == _PORTD_)	return ((_PORTD_IN>>bit_nr) & 0x01);
	else if (byte_adr == _PORTB_)	return ((_PORTB_IN>>bit_nr) & 0x01);
	else if (byte_adr == _PORTC_)	return ((_PORTC_IN>>bit_nr) & 0x01);
	else return 0;
}

//bit_write(_reg_, bit, val)	((val&0x01)? (_reg_ |= (0x01<<bit)): (_reg_ &= ~(0x01<<bit)))
void bit_write(volatile uint8_t *byte_adr, uint8_t bit_nr, uint8_t val)
{
	val &= 0x01;
	if (val == 1)
	*byte_adr |= (0x01<<bit_nr);
	else
	*byte_adr &= ~(0x01<<bit_nr);
}

uint8_t byte_read(volatile uint8_t *byte_adr)
{
	if		(byte_adr == _PORTD_)	return _PORTD_IN;
	else if (byte_adr == _PORTB_)	return _PORTB_IN;
	else if (byte_adr == _PORTC_)	return _PORTC_IN;
	else return 0;
}

//PORT als Ausgabe
void byte_write(volatile uint8_t *byte_adr, uint8_t byte_wert)
{
	*byte_adr = byte_wert;
}


//************************************************************
/* TR 3.2: PWM
 * Implementierung von PWM Arduino
 * PWM-Ausgang PB3 (D11)
 * Created: Baier (Stand 31.03.2016)
 *  Author: Baier
 */ 

uint8_t tgrad=0;
uint8_t pin=11; //Hier PWM Ausgang festlegen (z.B.: D11 = PB3)
 
void pwm_init()
{
   pinMode(pin, OUTPUT);	//PWM Pin als Ausgang          
   tgrad=127;                  	//Tastgrad 50% 
}

void pwm_start()
{
   analogWrite(pin, tgrad);
}

void pwm_stop()
{
   tgrad=0;                     //Tastgrad 0x00 = 0% = 0V / 0xFF = 100% = 5V
   analogWrite(pin, tgrad);
}

void pwm_duty_cycle(uint8_t value)	//��bergabe Tastgrad von 0..255 = 0..100%
{
   //PWM als Arduino DA-Funktion 
   tgrad = value;
}


//************************************************************
/*
 * TR 3.2: ADC
 * Implementierung von ADU f�r Arduino
 * Created: Baier (Stand 31.03.2016)
 *  Author: Baier
 */ 

void adc_init()
{
	//bei Arduino nicht erforderlich
}

uint8_t adc_in1()
{
	uint8_t  analog_8;
 	uint16_t analog_10;
	//uint8_t  analogPin = 1;  //Analogeingang A1
	uint8_t  analogPin = A3;   //Analogeingang A3, angepasst an HHS Arduino Board V1.5

	analog_10 = analogRead(analogPin); //10 Bit Aufl�sung
	analog_8  = map(analog_10,0,1023,0,255);

	return analog_8;    
}

uint8_t adc_in2()
{
	uint8_t  analog_8;
 	uint16_t analog_10;
	//uint8_t  analogPin = 2;  //Analogeingang A2
	uint8_t  analogPin = A0;  //Analogeingang A0, angepasst an HHS Arduino Board V1.5
	analog_10 = analogRead(analogPin); //10 Bit Aufl�sung
	analog_8  = map(analog_10,0,1023,0,255);

	return analog_8;    
}

//************************************************************