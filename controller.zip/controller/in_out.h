/*
 * Bibliothek: 		in_out.h
 * Version:			1.0
 * erstellt am:		30.09.2015
 * letzte �nderung:	02.04.2016
 * Autor:			Rahm, Baier
 */

/* TR 3.2 Beschreibung:
 * Header-Datei zur Umsetzung der Technischen Richtlinie FA205
 * f�r Arduino Uno.
 *  Bit-/Byte Ein-/Ausgabe
 */

#ifndef _PIN_H
#define _PIN_H

#include "controller.h"   //FA 205 Bibliothek

// Portregisterdefinitionen. K�nnen an dieser Stelle angepasst werden. 
#define _PORTD_CFG   DDRD			// PortD: 8 Bit
#define _PORTD_      &PORTD			// Vorsicht! PD0 = RxD (Input) PD1 = TxD (Output) m�ssen beim Programmieren floaten
#define _PORTD_IN    PIND			// Arduino-Pins: 0 ... 7

#define _PORTB_CFG   DDRB			// PortB: Nur 6 Bit nutzbar! PB6, PB7 => XTAL1, XTAL2
#define _PORTB_      &PORTB			// Arduino-Pins: 8 ... 13
#define _PORTB_IN    PINB			

#define _PORTC_CFG   DDRC			// PortC: 6 Bit
#define _PORTC_      &PORTC			// PC6 => Arduino Reset-Pin
#define _PORTC_IN    PINC			// Arduino-Pins: A0 ...A5

// Globale Schalter
#define PULLUPS
// Globale Symbole
#define IN  0x00
#define OUT 0x01

enum bits {bit0,bit1,bit2,bit3,bit4,bit5,bit6,bit7};

// Funktionen f�r Initialisierung
void    bit_init   ( volatile uint8_t *port, uint8_t bit, uint8_t dir );
void    byte_init  ( volatile uint8_t *port, uint8_t dir );

// IO-Funktionen
uint8_t bit_read   ( volatile uint8_t *port, uint8_t bit );
void    bit_write  ( volatile uint8_t *port, uint8_t bit, uint8_t state );
uint8_t byte_read  ( volatile uint8_t *port );
void    byte_write ( volatile uint8_t *port, uint8_t byte );





// PWM ******************************************************
//ge�ndert: Baier 01.10.2015

void pwm_init();
void pwm_start();
void pwm_stop();
void pwm_duty_cycle(uint8_t value);


// ADC ******************************************************
//ge�ndert: Baier 02.04.2016

void adc_init();
uint8_t adc_in1();
uint8_t adc_in2();


#endif
