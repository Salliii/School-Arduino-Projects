/*
 * Datei:   interrupt.cpp
 * f�r:     Arduino Uno 
 * Created: 04.10.2015
 * zuletzt ge�ndert:02.02.2019
 * Author:  Baier
 * Modifiziert durch M. Busch
 */

#include "interrupt.h"   //FA 205 Bibliothek
#include <TimerOne.h>    //Arduino Bibliothek

//*********************************
/* TR 3.3: Interrupt
 * Implementierung f�r Arduino
 * Interrupt-Eingabe am Port PD2 (Pin2)
*/ 

void ext_interrupt_init(void (*ip) (void))
{
	attachInterrupt(0, ip, FALLING);

}

void ext_interrupt_enable(void)
{
	//interrupts();
	EIFR |= 0x01;   //External Interruptflag wird r�ckgesetzt
	EIMSK |= 0x01;  //Ext Interrupt 0 wird freigegeben
	
}

void ext_interrupt_resetflag(void)  //notwendig wegen evetuellem Prellverhalten
{
	EIFR |= 0x01;   //External Interruptflag wird r�ckgesetzt
}

void ext_interrupt_disable(void)
{
	//noInterrupts();
	EIMSK &= 0xFE;  //Ext Interrupt 0 wird gesperrt
}

//*********************************
/* TR 3.3: Timer (1ms)
 * Implementierung f�r Arduino
*/
 
void timer1ms_init(void (*ip) (void))
{
	Timer1.initialize(1000);       	//T=1000�s
	Timer1.attachInterrupt(ip);	//Timer aktivieren
	Timer1.stop();                  //Timer stoppen
}

void timer1ms_enable(void)
{
	Timer1.setPeriod(1000);		//T=1000�s
	Timer1.restart();		//Timer von Beginn starten
}

void timer1ms_disable(void)
{
	Timer1.stop();			//Timer stoppen
}
