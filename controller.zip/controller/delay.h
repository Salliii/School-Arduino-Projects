/*
 *Bibliothek: 		delay.h
 *Version:			1.0
 *erstellt am:		30.10.2015
 *letzte �nderung:	02.04.2015
 *Autor:		Baier
 *
 */

/* TR 3.1: Beschreibung:
 * Header-Datei zur Umsetzung der Technischen Richtlinie FA205
 * f�r Arduino Uno.
 */


#include "controller.h"   //FA 205 Bibliothek


extern void delay_100us(uint16_t hundertMicrosec);
extern void delay_ms(uint16_t millisec);

