/*
 * Datei:   communicationV2.cpp
 * f�r:     Arduino Uno 
 * Created: 12.05.2019
 * ge�ndert:12.05.2019
 * Author:  Busch
 */

#include "communicationV2.h"   //FA 205 Bibliothek
//#include <Wire.h>           //Arduino Bibliothek



/* TR 3.5
 * RS232 Serielle Schittstelle (virtuell USB)
 * Implementierung f�r Arduino
 * 
*/ 

void rs232_init(void)
{
	Serial.begin(9600);
}

uint8_t rs232_get(void)
{
	//if(Serial.available() > 0){return Serial.read();}
	char z;
	if(Serial.available() > 0)
	{
		z = Serial.read();
		if(z == 255)
			return '\0';
		else
			return z; 
	}
}

void rs232_put(uint8_t value)
{
	Serial.write(value);
}


void rs232_print(uint8_t text[])
{
	String str="";
	int pos=0;
	while( text[pos]!=0 ) {
		str = str+(char)text[pos];
		pos++;
	}
	Serial.print(str);	
}

//�berladene Methode f�r Zeichenkette
void rs232_print(String str)
{
	Serial.print(str);	
}

/**************************************************
 * TR 3.5 I2C-Bussystem
 * Implementierung f�r Arduino
*/

 
 //************************************************
 void short_delay (void)
 {
	 uint16_t j;
	 for(j = 65535; j != 0; j--){}
 }
 
 void takt(void)
 {
	 digitalWrite(SCL, HIGH);
	 short_delay();
	 digitalWrite(SCL, LOW);
	 short_delay();
 }
 
void i2c_init(void)
{
	pinMode(SDA, OUTPUT);
	pinMode(SCL, OUTPUT);
	digitalWrite(SDA, HIGH);
	digitalWrite(SCL, HIGH);
	for(uint16_t i=65535; i!=0; i--);
}

void i2c_start(void)
{	
	digitalWrite(SDA, LOW);				// Startbed.: SDA: ���\_______
 	short_delay();
 	digitalWrite(SCL, LOW);       		//            SCL: �������\___
 	short_delay();
}

uint8_t i2c_start_addrRW(uint8_t adresse)
{	
	uint8_t reg0, reg1, i;
	
	digitalWrite(SDA, LOW);				// Startbed.: SDA: ���\_______
 	short_delay();
 	digitalWrite(SCL, LOW);       		//            SCL: �������\___
 	short_delay();
	do
	{
 		digitalWrite(SCL, LOW);
		reg0 = 0x80;
 		
 		for (i=8; i!=0; i--)			// adress out
 		{ 
 			reg1 = reg0 & adresse;
 			if (reg1 != 0) digitalWrite(SDA, HIGH);
 			else digitalWrite(SDA, LOW);
 			takt ();
 			reg0 = reg0 >> 1;
 		}
		digitalWrite(SDA, HIGH);
		pinMode(SDA, INPUT);
		short_delay();
 		digitalWrite(SCL, HIGH);	
 	}while (digitalRead(SDA) == 1);		//w�hrend SCL=1 wird SDA abgefragt
	digitalWrite(SCL, LOW);
	pinMode(SDA, OUTPUT);
	return 0;							//acknowledge by slave
}

uint8_t i2c_read(uint8_t ack)
{	
	uint8_t reg0, reg1, i;
	reg1 = 0x80;
 	reg0 = 0x00;
 	pinMode(SDA, INPUT);
 	for (i=8; i!=0; i--)					// d15..d8 in
 	{
 		digitalWrite(SCL, HIGH);
 		if (digitalRead(SDA) == 1) reg0 = reg1 | reg0;
 		digitalWrite(SCL, LOW);
 		reg1 = reg1 >> 1;
 	}
 	pinMode(SDA, OUTPUT);
	if(ack == 0) digitalWrite(SDA, LOW);
	else digitalWrite(SDA, HIGH);			//ackn by master
 	takt ();
	return reg0;
}

void i2c_stop(void)
{
	digitalWrite(SDA, LOW);			// Stopbedingung   SDA: ���\_______/������
 	short_delay();
 	digitalWrite(SCL, HIGH);       	//                 SCL: ________/��������
 	short_delay();
	digitalWrite(SDA, HIGH);
}
/*
uint8_t i2c_write(uint8_t val)
{ 
	uint8_t reg0, reg1, i, acknowledgebit;
	
	digitalWrite(SCL, LOW);
	reg0 = 0x80;
 		
 	for (i=8; i!=0; i--)					// value out...
 	{ 
 		reg1 = reg0 & val;
 		if (reg1 != 0) digitalWrite(SDA, HIGH);
 		else digitalWrite(SDA, LOW);
 		takt ();
 		reg0 = reg0 >> 1;
 	}
 	digitalWrite(SDA, HIGH);	 		//SDA=1 f�r auf ackn by slave
	pinMode(SDA, INPUT);				//
	short_delay();
 	takt();
	acknowledgebit = digitalRead(SDA);
	pinMode(SDA, OUTPUT);
	return acknowledgebit;				//ACKNOWLEDGEBIT zur�ckgeben
}*/

void i2c_write(uint8_t val)
{ 
	uint8_t reg0, reg1, i, acknowledgebit;
	
	digitalWrite(SCL, LOW);
	reg0 = 0x80;
 		
 	for (i=8; i!=0; i--)					// value out...
 	{ 
 		reg1 = reg0 & val;
 		if (reg1 != 0) digitalWrite(SDA, HIGH);
 		else digitalWrite(SDA, LOW);
 		takt ();
 		reg0 = reg0 >> 1;
 	}
 	digitalWrite(SDA, HIGH);	 		//SDA=1 f�r auf ackn by slave
	short_delay();
 	takt();
}

 
 