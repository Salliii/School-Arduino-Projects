/*
 * Bibliothek: 		interrupt.h
 * Version:			1.0
 * erstellt am:		30.09.2015
 * letzte �nderung:	16.8.2018 von M.Busch
 * Autor:			Baier
 */

/* TR 3.3 Beschreibung:
 * Header-Datei zur Umsetzung der Technischen Richtlinie FA205
 * f�r Arduino Uno.
 * Externer Interrupt0  an PD2 (Pin2) und Timer-Interrupt
*/

#ifndef RUN
#define RUN  1
#endif
#ifndef STOP
#define STOP 0
#endif

#include "controller.h"  //FA 205 Bibliothek

//TR 3.3 Ext. Interrupt ****************************
//�bergabe eines Funktionspointers
void ext_interrupt_init(void (*isr_pointer) (void));
void ext_interrupt_enable(void);
void ext_interrupt_disable(void);
void ext_interrupt_resetflag(void);		//notwendig wegen evetuellem Prellverhalten

//TR 3.3 Timer-Interrupt ****************************
//�bergabe eines Funktionspointers
void timer1ms_init(void (*isr_pointer) (void));
void timer1ms_enable(void);
void timer1ms_disable(void);

