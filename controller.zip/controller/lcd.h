/*
 * Bibliothek: 		lcd.h
 * Version:		    1.0
 * erstellt am:		02.04.2016
 * letzte �nderung:	03.04.2016
 * Autor:		    Baier
 */

/* TR 3.4: LC-Display
*/

#include "controller.h"   //FA 205 Bibliothek

//LC-Display
void lcd_init(void);
void lcd_clear(void);
void lcd_setcursor(uint8_t row, uint8_t column);
void lcd_print(uint8_t text[]);
void lcd_print(String str);
void lcd_char(uint8_t value);
void lcd_byte(uint8_t value);
void lcd_int(uint16_t value);
