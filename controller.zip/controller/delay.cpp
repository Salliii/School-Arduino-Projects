/*
 * Datei:	 delay.cpp
 * f�r:		 Arduino UNO
 * Created:  28.10.2015 00:23:49
 * �nderung: 02.04.2016
 * Author:   Baier
 */ 

#include "delay.h"   //FA 205 Bibliothek

 /*
  * TR 3.1: Verz�gert der Programmablauf Implementierung Arduino
  */

void delay_100us(uint16_t hundertMicrosec)
{
	uint16_t n = 0;
		
	while(n < hundertMicrosec)
	{
		delayMicroseconds(100);	// Arduino-Funktion
		n++;
	}
}

void delay_ms( uint16_t millisec)
{
		delay(millisec);        // Arduino-Funktion
		
}
