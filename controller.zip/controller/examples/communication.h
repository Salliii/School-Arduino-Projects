/*
 * Bibliothek: 		communication.h
 * Version:		    1.0
 * erstellt am:		02.04.2016
 * letzte �nderung:	03.04.2016
 * Autor:		    Baier
 */

/* TR 3.5 Beschreibung:
   Serielle Schnittstelle und I2C-Bus
*/

#include "controller.h" //FA 205 Bibliothek

//I2C Slaveadresse festlegen
//#define SLAVE_ADR 0x4D	//hier ADU MCP3221 7-Bit-Adr
#define SLAVE_ADR 0x48	//hier LM75 Adr.: 91 >> 1 = 48


//RS232 Serielle Schittstelle
void    rs232_init(void);
uint8_t rs232_get(void);
void    rs232_put(uint8_t value);
void    rs232_print(uint8_t text[]);
void    rs232_print(String str);

//I2C-Bussystem
void    i2c_init(void);
void    i2c_start(void);
void    i2c_stop(void);
uint8_t i2c_write(uint8_t value);
uint8_t i2c_read(uint8_t ack);
