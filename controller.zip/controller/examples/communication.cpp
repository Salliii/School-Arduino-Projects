/*
 * Datei:   communication.cpp
 * f�r:     Arduino Uno 
 * Created: 02.04.2016
 * ge�ndert:03.04.2016
 * Author:  Baier
 */

#include "communication.h"   //FA 205 Bibliothek
#include <Wire.h>           //Arduino Bibliothek

/* TR 3.5
 * RS232 Serielle Schittstelle (virtuell USB)
 * Implementierung f�r Arduino
 * 
*/ 

void rs232_init(void)
{
	Serial.begin(9600);
}

uint8_t rs232_get(void)
{
	if(Serial.read() == -1)
		return '\0';
	else
	    return Serial.read(); 
}

void rs232_put(uint8_t value)
{
	Serial.write(value);
}


void rs232_print(uint8_t text[])
{
	String str="";
	int pos=0;
	while( text[pos]!=0 ) {
		str = str+(char)text[pos];
		pos++;
	}
	Serial.print(str);	
}

//�berladene Methode f�r Zeichenkette
void rs232_print(String str)
{
	Serial.print(str);	
}

/**************************************************
 * TR 3.5 I2C-Bussystem
 * Implementierung f�r Arduino
*/

void i2c_init(void)
{
	Wire.begin();  //Arduino als Master, somit muss keine Adresse mitgeliefert werden
}

void i2c_start(void)			//liefert Startbedingung und Adresse an Slaves
{	
	uint8_t anzahl_Byte =2;			//urspr�nglich 2
	Wire.beginTransmission(SLAVE_ADR);  
	Wire.requestFrom(SLAVE_ADR, anzahl_Byte);
}

void i2c_stop(void)
{
	Wire.endTransmission();
}

uint8_t i2c_write(uint8_t val)
{ 
	Wire.write(val);
	return 0;        //R�ckgabe nicht benutzt     
}

 //schonDa zeigt an, ob i2c_read() zuvor schon mal aufgerufen
static uint8_t schonDa=0; 

uint8_t i2c_read(uint8_t ack)
{	
	uint8_t wert;
	if(schonDa==0) 
	{
		if(ack==1) 		//NACK
		{ 
			Wire.requestFrom(SLAVE_ADR, 1);
			wert = Wire.read();
			schonDa=0;
		}
		else 				//ACK
		{       
			Wire.requestFrom(SLAVE_ADR, 2); 
			//es kommt noch ein Wire.read()
			wert = Wire.read();
			schonDa=1;
		}
	}
	else 
	{           			//schonDa==1
		if(ack==1) 		//NACK
		{ 
			wert = Wire.read();
			schonDa=0;
		}
		else 
		{       			//ACK
			wert =  Wire.read(); //0xFF; //Fehler
			schonDa=0;
		}
	}
	return wert;
}
//************************************************
