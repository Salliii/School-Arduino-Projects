//Bibliothek: 		ControllerV2.h
//Version:			2.0
//erstellt am:		14.02.2019
//letzte �nderung:	14.02.2019
//Autor:			Baier, ge�ndert von Busch

/* TR 3.0 Beschreibung:
   Header-Datei zur Umsetzung der Technischen Richtlinie FA205
   f�r Arduino Uno.
*/


#ifndef _CONTROLLER_H_
#define _CONTROLLER_H_

#define F_CPU 16000000UL
  //#define _ATMEGA8_      // MyAVR
#define _ATMEGA328_    // Arduino Uno


//********************************************
// Arduino Header

     #include <arduino.h>

//********************************************
// TR 3.0 Header-Dateien FA205

   #include "delay.h"           //TR 3.1
   #include "in_out.h"	        //TR 3.2
   #include "interrupt.h"       //TR 3.3
   #include "lcd.h"             //TR 3.4
   #include "communicationV2.h" //TR 3.5



//********************************************
//TR 1.2 Verwendete Datentypen

  typedef signed   char int8_t;
  typedef unsigned char uint8_t;
  typedef signed   int  int16_t;
  typedef unsigned int  uint16_t;
  typedef signed   long int32_t;
  typedef unsigned long uint32_t;


#endif
