DFPlayer-Mini-mp3
=================

Install instructions:

* Download file
* decompress
* copy inside folder to your Arduino library folder
* restart your Arduino IDE


Check the wiki for more information:
http://www.dfrobot.com/wiki/index.php/DFPlayer_Mini_SKU:DFR0299
